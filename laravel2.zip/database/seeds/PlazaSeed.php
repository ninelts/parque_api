<?php

use Illuminate\Database\Seeder;

class PlazaSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      $plaza = [
        ['id' => 1 , 'nombre' => 'Plaza-1', 'estado' => 1 ],
        ['id' => 2 , 'nombre' => 'Plaza-2', 'estado' => 1 ],
        ['id' => 3 , 'nombre' => 'Plaza-3', 'estado' => 1 ]
      ];
      DB::connection('mysql')->table('plaza')->insert($plaza);
    }
}
