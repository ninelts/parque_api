<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\modelos\CarritoCompra;
use App\modelos\CantidadProductos;
use App\modelos\BloqueReservaPlaza;

class CarritoCompraController extends Controller
{


	public function insertCarritoCompra(Request $request){


		$array_productos = $request->resultado;
		$cantidadTotal = count($array_productos);
		$precioTotal = 0;

		// dump($array_productos); 

		foreach ($array_productos as $value) {

			$precioTotal = $precioTotal + $value['precio'];

		}

		try {

			CarritoCompra::insert([
				'estado' => 0,
				'cod_carrito_compra' => null,
				'precio_total' => $precioTotal,
				'cantidad_productos' => $cantidadTotal,
				'user_id' => $request->id_usuario,
				'created_at' => date('Y-m-d H:i:s'),
				'updated_at' => date('Y-m-d H:i:s'),
			]);

			$collectionCarritoCompra = CarritoCompra::where('user_id' , $request->id_usuario)->latest()->first();

			foreach ($array_productos as $value) {

				CantidadProductos::insert([
					'bloque_plaza_reserva_id' => $value['id'],
					'carrito_de_compra_id' => $collectionCarritoCompra->id,
					'created_at' => date('Y-m-d H:i:s'),
					'updated_at' => date('Y-m-d H:i:s'), 


				]);

			}

			CarritoCompra::where('id' , $collectionCarritoCompra->id)->update(['cod_carrito_compra' => 'ccp'.$collectionCarritoCompra->id]);
			
			$collectionCantidadProductos = CantidadProductos::where('carrito_de_compra_id', $collectionCarritoCompra->id)->get()->pluck('bloque_plaza_reserva_id');
			$collectionProductosDetalle = BloqueReservaPlaza::whereIn('id', $collectionCantidadProductos)->get()->toArray();
			$parametros = array(

				'id_carrito' => $collectionCarritoCompra->id,
				'precio_total' => $collectionCarritoCompra->precio_total,
				'cantidad' => $collectionCarritoCompra->cantidad_productos,
				'cod_carrito_compra' => $collectionCarritoCompra->cod_carrito_compra,
				'user_id' => $collectionCarritoCompra->user_id,
				'productos_detalle' => $collectionProductosDetalle

			);
			dump($parametros);

			return response()->json(['estado' => true , 'parametros' => $parametros]);
			// return redirect()->route('details', array('id' => $id, 'name' => $name));

		} catch (Exception $e) {
			return $e;
		}
		


        }


    }
